import fs from 'fs'
import { CrossEntropy, Embedding, Linear, PositionEmbedding, ReLu, SelfAttention, Softmax, Tokenizer, Tools } from '@mineproness/tensorloop'
import yaml from 'yaml'


// Init all Things
const config = yaml.parse(fs.readFileSync("./config.yaml", "utf-8"))
const tokenizer = new Tokenizer()
const embedding = new Embedding(config.EMBEDDING_SIZE, tokenizer.vocabSize, {
    save: {
        filename: `${config.DIRNAME}/vectors.bin`
    }
})
const linear = new Linear(config.EMBEDDING_SIZE, tokenizer.vocabSize, {
    save: {
        filename: [`${config.DIRNAME}/weights.bin`, `${config.DIRNAME}/bias.bin`]
    }
})
const selfAttention = new SelfAttention(config.EMBEDDING_SIZE, {
    dirname: config.DIRNAME
})
const softmax = new Softmax()
const positionEmbedding = new PositionEmbedding(config.EMBEDDING_SIZE, config.CONTEXT_SIZE, {
    save: {
        filename: `${config.DIRNAME}/posVectors.bin`
    }
})
function NextToken(probs) {
    const r = Math.random()
    let sum = 0;
    for (let i = 0; i < probs.length; i++) {
        sum += probs[i]
        if (r <= sum) return i
    }
    return probs.length - 1
}
function generate(request) {
    const tokens = tokenizer.encoder(request).tokenIDs
    const output = [...tokens]
    for (let a = 0; a < 20; a++) {
        let x = embedding.forward(tokens)
        x = positionEmbedding.addPos(x)
        x = selfAttention.forward(x)
        const logits = x.map((e) => linear.forward(e))
        const probs = softmax.forward(logits[logits.length - 1])
        let nextToken = 0;

        for (let i = 1; i < probs.length; i++) {
            if (probs[i] > probs[nextToken]) {
                nextToken = i;
            }
        }
        if(tokenizer.decoder([nextToken]) == "<s>"){
            break;
        }
        tokens.push(nextToken)
        output.push(nextToken)
        if (tokens.length > config.CONTEXT_SIZE) {
            tokens.shift()
        }
    }
    console.log(tokenizer.encoder(tokenizer.decoder(output)).tokens)
}

generate("Human 1: Hi!".toLocaleLowerCase())