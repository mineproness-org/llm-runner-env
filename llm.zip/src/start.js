import path, { dirname, join } from 'path'
import { fileURLToPath } from 'url'
import { execSync, spawn } from 'child_process'
import express from 'express'
import { Server } from 'socket.io'
import http from 'http'
import GetConfig from './GetConfigs.js'
import { log } from 'console'
import fs from 'fs'
// color
let version = "1.0.0"
const blue = '\x1b[34m'
const reset = '\x1b[0m'
const red = '\x1b[31m'
const green = '\x1b[32m'
const yellow = '\x1b[33m'
const pulpurl = '\x1b[35m'
const __dirname = join(dirname(fileURLToPath(import.meta.url)), "../")
let trainProcess = null;
let generateProcess = null;
let allList = []
let logs = []
let isWindows = process.platform == "win32"
const app = express()
const server = http.createServer(app)
const socket = new Server(server, {
    cors: {
        origin: "*"
    }
})

socket.on("connection", (io) => {
    logs.map((e) => {
        socket.emit("server_log", e)
    })
    if (trainProcess) {
        socket.emit("status_change", "running")

    } else {
        socket.emit("status_change", "stopped")

    }
})
app.use(express.json())
app.use(express.static(join(__dirname, "public")))
app.use((req, res, next) => {
    next()
    console.log(` ${req.url} ${pulpurl}${res.statusCode}${reset} ${req.method}`)
})

app.get("/", (req, res) => {
    res.sendFile(join(__dirname, "./pages/index.html"))
})

app.get("/generate", (req, res) => {
    res.sendFile(join(__dirname, "./pages/generate/index.html"))
})

app.post("/api/restartTrain", async (req, res) => {
    if (trainProcess) {
        await fetch(`http://localhost:${GetConfig.PORT}/api/stopTrain`, { method: "POST" })
        await fetch(`http://localhost:${GetConfig.PORT}/api/startTrain`, { method: "POST" })
        res.send({ error : false })
    }else{
        res.send({error:true, resson: "Training pair is stopped already."})
    }
})
app.post("/api/startTrain", (req, res) => {
    if (trainProcess) {
        res.status(400).send({
            error: true,
            resson: "The train already started."
        })
    } else {
        trainProcess = spawn("node --prof src/trainer.js", {
            shell: true
        })
        res.status(200).send({
            error: false,
        })
        socket.emit("status_change", "running")
        trainProcess.stdout.on("data", (data) => {
            const Arr = data.toString().split("|").map((e => e.trim().replaceAll("\n", ""))).map((e) => e.split(":"))
            const objectData = Object.fromEntries(Arr.map((e) => e))
            if (logs.length == 300) {
                logs = []
                socket.emit("clear_log", true)
            }
            logs.push(`[${new Date().toISOString()}]: ${data.toString().replaceAll(":", " : ")}`)
            socket.emit("server_log", `[${new Date().toISOString()}]: ${data.toString().replaceAll(":", " : ")}`)
            socket.emit("progress_train", objectData)
        })
        trainProcess.on("exit", () => {
            trainProcess = null;
            socket.emit("status_change", "stopped")
            logs.push(`[${new Date().toISOString()}]: Training Pair is Stopped.`)
            socket.emit("server_log", `[${new Date().toISOString()}]: Training Pair is Stopped.`)
        })
        logs.push(`[${new Date().toISOString()}]: Training Pair is Started.`)
        socket.emit("server_log", `[${new Date().toISOString()}]: Training Pair is Started.`)
    }
})
app.post("/api/stopTrain", (req, res) => {
    if (!trainProcess) {
        res.status(400).send({
            error: true,
            resson: "The train already stopped."
        })
    } else {
        if (isWindows) {
            execSync(`taskkill /pid ${trainProcess.pid} /T /F`, { stdio: 'ignore' })
        } else {
            process.kill(trainProcess.pid, "SIGTERM")
        }
        trainProcess = null;
        res.send({ error: false })
    }
})
app.post("/api/clearLogs", (req, res) => {
    logs = [];
    socket.emit("clear_log", true);
    res.send("Cleared!")
})

server.listen(GetConfig.PORT, () => {
    logs.push(`[${new Date().toISOString()}]: Backend Server started correctly.`)
    process.stdout.write("\x1Bc")
    console.log()
    console.log(`${pulpurl} @mineproness/bllm ${version} • ${reset}`)
    console.log()
    console.log(`${yellow} ⚠️ BLLM backend API running on ${GetConfig.PORT} ${reset}`)
    console.log()
    console.log(` LOCAL URL: http://localhost:${GetConfig.PORT} `)
    console.log(` Config FILE: '${__dirname}config.yaml' `)
    console.log(` CONTEXT SIZE: ${GetConfig.CONTEXT_SIZE} `)
    console.log(` EMBEDDING SIZE: ${GetConfig.EMBEDDING_SIZE} `)
    console.log(` LEARNING RATE: ${GetConfig.LEARNING_RATE} `)
    console.log()
    console.log(" --------------------------------")
    console.log(" --------------------------------")
    console.log()
    const configWatcher = fs.watch(join(__dirname, "config.yaml"), {
        recursive: true,
        ignore: true,
        persistent: true,
        encoding: "utf-8"
    })
    let change = false
    configWatcher.on("change", async () => {
        change = true

    })
    setInterval(async () => {
        if (change) {
            change = false
            socket.emit("server_log", `[${new Date().toISOString()}]: Config Change Detected. Restarting Training Pair if needed.`)
            logs.push(`[${new Date().toISOString()}]: Config Change Detected. Restarting Training Pair if needed.`)
            if (trainProcess) {
                await fetch(`http://localhost:${GetConfig.PORT}/api/restartTrain`, {
                    method: "POST"
                })
            }
        }
    }, 5000)
})
