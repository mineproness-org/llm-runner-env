import { existsSync, mkdir, mkdirSync, readFileSync } from 'fs'
import path, { dirname, join } from 'path'
import { fileURLToPath } from 'url'
import { CrossEntropy, Embedding, Linear, PositionEmbedding, ReLu, SelfAttention, Softmax, Tokenizer } from '@mineproness/tensorloop'
import GetConfig from './GetConfigs.js'
const __dirname = join(dirname(fileURLToPath(import.meta.url)), "../model")
if (!existsSync(__dirname)) mkdirSync(__dirname);
const tokenizer = new Tokenizer()
const embedding = new Embedding(GetConfig.EMBEDDING_SIZE, tokenizer.vocabSize, {
    save: { filename: join(__dirname, "vectors.bin") }
})
const softmax = new Softmax()
const posEmbedding = new PositionEmbedding(GetConfig.EMBEDDING_SIZE, GetConfig.CONTEXT_SIZE, {
    save: { filename: join(__dirname, "posVectors.bin") }
})
const selfattention = new SelfAttention(GetConfig.EMBEDDING_SIZE, {
    dirname: __dirname
})
const linear = new Linear(GetConfig.EMBEDDING_SIZE, tokenizer.vocabSize, {
    save: { filename: [join(__dirname, "weights.bin"), join(__dirname, "bias.bin")] }
})
const linear1 = new Linear(GetConfig.EMBEDDING_SIZE, 4 * GetConfig.EMBEDDING_SIZE, {
    save: { filename: [join(__dirname, "weights1.bin"), join(__dirname, "bias1.bin")] }
})
const linear2 = new Linear(4 * GetConfig.EMBEDDING_SIZE, GetConfig.EMBEDDING_SIZE, {
    save: { filename: [join(__dirname, "weights2.bin"), join(__dirname, "bias2.bin")] }
})
const relu = new ReLu()
const tokenSet = readFileSync("./src/dataset.txt", "utf-8").split("\n").filter((e) => e.trim().length > 0).flatMap((e) => tokenizer.encoder(e).tokenIDs)
const trainingPairs2 = []
for (let a = 0; a + GetConfig.CONTEXT_SIZE < tokenSet.length; a++) {
    trainingPairs2.push({
        inputIDX: tokenSet.slice(a, a + GetConfig.CONTEXT_SIZE),
        targetIDX: tokenSet.slice(a + 1, a + GetConfig.CONTEXT_SIZE + 1)
    })
}
const trainingPairs = []
const chunkSize = 1500
for (let a = 0; a < trainingPairs2.length; a += chunkSize) {
    trainingPairs.push(trainingPairs2.slice(a, a + chunkSize))
}
let idx = GetConfig.INDEX;
let trainingPair = trainingPairs[idx]
for (let i = 0; i < GetConfig.EPOCHS; i++) {
    let totalLoss = 0;
    for (let a = 0; a < trainingPair.length; a++) {
        const { inputIDX, targetIDX } = trainingPair[a]
        const xEM = embedding.forward(inputIDX);
        const xPOS = posEmbedding.addPos(xEM)
        const attention = selfattention.forward(xPOS)
        const xLI = []
        for (let h = 0; h < attention.length; h++) {
            const output1 = linear1.forward(attention[h])
            const hidden = relu.forward(output1)
            const output2 = linear2.forward(hidden)
            xLI[h] = linear.forward(output2)
        }
        const probs = []
        for (let j = 0; j < xLI.length; j++) {
            probs[j] = softmax.forward(xLI[j])
        }
        let loss = 0;
        for (let h = 0; h < probs.length; h++) {
            loss += CrossEntropy(probs[h], targetIDX[h])
        }
        let DProbs = []
        for (let h = 0; h < probs.length; h++) {
            DProbs[h] = softmax.backward(probs[h], targetIDX[h])
        }
        const dLinear = []
        for (let h = 0; h < DProbs.length; h++) {
           const dOutput = linear.backward(DProbs[h], GetConfig.LEARNING_RATE, h)
           const dOutput2 = linear2.backward(dOutput, GetConfig.LEARNING_RATE ,h)
           const dHidden = relu.backward(dOutput2)
           dLinear[h] = linear1.forward(dHidden)
        }
        const dAttention = selfattention.backward(dLinear, GetConfig.LEARNING_RATE)
        for (let h = 0; h < dAttention.length; h++) {
            posEmbedding.backward(h, dAttention[h], GetConfig.LEARNING_RATE)
            embedding.backward(inputIDX[h], dAttention[h], GetConfig.LEARNING_RATE)
        }
        loss /= probs.length;
        totalLoss += loss
        console.log(`type:progress | loss:${(totalLoss / (a + 1)).toFixed(4)} | totalPair:${trainingPair.length} | Completedpair:${a + 1} | TotalEPOCHS:${GetConfig.EPOCHS} | CompletedEPOCHS:${i + 1}`)
        linear.ClearInputCache()
        linear1.ClearInputCache()
        linear2.ClearInputCache()
        selfattention.query.ClearInputCache()
        selfattention.key.ClearInputCache()
        selfattention.value.ClearInputCache()

    }
    console.log(`type:finished | loss:${(totalLoss / trainingPair.length).toFixed(4)} | totalPair:${trainingPair.length} | TotalEPOCHS:${GetConfig.EPOCHS} | CompletedEPOCHS:${i + 1}`)
    embedding.Save()
    posEmbedding.Save()
    selfattention.Save()
    linear.Save()
    linear1.Save()
    linear2.Save()
    if ((totalLoss / trainingPair.length) <= 0.5) {
        process.exit(0)
    }
  
}