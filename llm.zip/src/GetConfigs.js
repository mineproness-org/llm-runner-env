import yaml from 'yaml'
import fs from 'fs'
import { dirname, join } from 'path'
import { fileURLToPath } from 'url'

const __filename = join(dirname(fileURLToPath(import.meta.url)), "../config.yaml")
const config = yaml.parse(fs.readFileSync(__filename, "utf-8"))
export default config
