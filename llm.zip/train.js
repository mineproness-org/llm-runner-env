import fs from 'fs'
import { CrossEntropy, Embedding, Linear, PositionEmbedding, ReLu, SelfAttention, Softmax, Tokenizer, Tools } from '@mineproness/tensorloop'
import yaml from 'yaml'


// Init all Things
const config = yaml.parse(fs.readFileSync("./config.yaml", "utf-8"))
const tokenizer = new Tokenizer()
const embedding = new Embedding(config.EMBEDDING_SIZE, tokenizer.vocabSize, {
    save: {
        filename: `${config.DIRNAME}/vectors.bin`
    }
})
const linear = new Linear(config.EMBEDDING_SIZE, tokenizer.vocabSize, {
    save: {
        filename: [`${config.DIRNAME}/weights.bin`, `${config.DIRNAME}/bias.bin`]
    }
})
const selfAttention = new SelfAttention(config.EMBEDDING_SIZE, {
    dirname: config.DIRNAME
})
const softmax = new Softmax()
const positionEmbedding = new PositionEmbedding(config.EMBEDDING_SIZE, config.CONTEXT_SIZE, {
    save: {
        filename: `${config.DIRNAME}/posVectors.bin`
    }
})

// Create TrainingPairs
const tokensofDataset = fs.readFileSync("./dataset.txt", "utf-8").split("\n")
    .map((e) => tokenizer.encoder(`${e} <s>`).tokenIDs).flat()
const trainingPairs2 = []
for (let i = 0; i <= tokensofDataset.length - config.CONTEXT_SIZE - 1; i++) {
    trainingPairs2.push({
        inputIDX: tokensofDataset.slice(i, i + config.CONTEXT_SIZE),
        targetIDX: tokensofDataset.slice(i + 1, i + config.CONTEXT_SIZE + 1)
    })
}

const TrainingPairs = []
const dividedPair = Math.floor(trainingPairs2.length / 200)
for (let a = 0; a < (trainingPairs2.length - 1); a += dividedPair) {
    TrainingPairs.push(trainingPairs2.slice(a, a + dividedPair))
}
process.stdout.write("\x1Bc")

const trainingPair = TrainingPairs[0]
console.log("")
for (let a = 0; a < config.ECPHOS; a++) {
    let epochLoss = 0;
    const startPair = performance.now()

    for (let i = 0; i < trainingPair.length; i++) {
        const startTime = performance.now()
        const { targetIDX, inputIDX } = trainingPair[i]
        const xEM = embedding.forward(inputIDX)
        const xPOS = positionEmbedding.addPos(xEM)
        const attention = selfAttention.forward(xPOS)
        
        const logits = []
        for (let j = 0; j < attention.length; j++) {
            logits[j] = linear.forward(attention[j]) 
        }

    
        let sampleLoss = 0;
        const probs = logits.map(l => softmax.forward(l))
        
        for (let tt = 0; tt < probs.length; tt++) {
            sampleLoss += CrossEntropy(probs[tt], targetIDX[tt])
        }
        
        const stepLoss = sampleLoss / probs.length;
        epochLoss += stepLoss;

      
        const dLogits = []
        for (let h = 0; h < probs.length; h++) {
            dLogits[h] = softmax.backward(probs[h], targetIDX[h]) 
        }

     
        const dAttention = []
        for (let h = 0; h < dLogits.length; h++) {
           
            dAttention[h] = linear.backward(dLogits[h], config.LEARNING_RATE, h)
        }

        const dInput = selfAttention.backward(dAttention, config.LEARNING_RATE)

  
        for (let h = 0; h < dInput.length; h++) {
        
            const gran = dInput[h].map(val => Math.max(-1.0, Math.min(1.0, val)))
            embedding.backward(inputIDX[h], gran, config.LEARNING_RATE)
            positionEmbedding.backward(h, gran, config.LEARNING_RATE)
        }

        const endTime = (performance.now() - startTime) / 1000
        const elapsed = performance.now() - startPair
        const minPair = Math.floor(elapsed / (1000 * 60))
        const secPair = Math.floor((elapsed % 60000) / 1000)
        
        const currentAvgLoss = epochLoss / (i + 1);

        process.stdout.write(
            `\rEpoch ${a + 1}/${config.ECPHOS} | ${((i + 1) / trainingPair.length * 100).toFixed(2)}% | Total Training Pair ${trainingPair.length} | Loss ${currentAvgLoss.toFixed(4)} | Takes about ${endTime.toFixed(2)}s (${minPair}m ${secPair}s)`
        )
        linear.ClearInputCache()
        selfAttention.query.ClearInputCache()
        selfAttention.key.ClearInputCache()
        selfAttention.value.ClearInputCache()
    }


    selfAttention.Save()
    linear.Save()
    embedding.Save()
    positionEmbedding.Save()
    console.log()
}